-- 03_seed.sql
insert into app_config (key, value)
values
  ('feature_flags', '{
    "ai_feed_enabled": false,
    "personalized_feed_enabled": false,
    "shadow_moderation_enabled": false,
    "growth_feed_bonus_enabled": false
  }'::jsonb),
  ('feed_weights', '{
    "ai": 0.32,
    "quality": 0.18,
    "engagement": 0.20,
    "freshness": 0.15,
    "trust": 0.10,
    "visibility": 0.05
  }'::jsonb),
  ('ab_test', '{
    "enabled": false,
    "traffic_split_ai": 50
  }'::jsonb)
on conflict (key) do nothing;

insert into draws (type, title, status, starts_at, ends_at)
values
  ('day', 'Päivän kierros', 'active', now(), now() + interval '1 day'),
  ('week', 'Viikon kierros', 'active', now(), now() + interval '7 day'),
  ('month', 'Kuukauden kierros', 'active', now(), now() + interval '1 month')
on conflict do nothing;
