-- 01_schema.sql
create extension if not exists pgcrypto;

create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid unique,
  display_name text,
  city text,
  avatar_url text,
  is_bot boolean default false,
  is_admin boolean default false,
  subscription_status text default 'free',
  subscription_expires_at timestamptz,
  is_test_user boolean default false,
  reputation_score numeric default 0.5,
  trust_level text default 'new',
  participation_score numeric default 0,
  quality_score numeric default 0.5,
  vote_reliability numeric default 0.5,
  streak_days integer default 0,
  last_vote_at timestamptz,
  last_post_at timestamptz,
  last_active_at timestamptz default now(),
  player_dna text,
  persuasion_style text,
  mentor_summary text,
  invite_code text unique,
  invited_by uuid references profiles(id),
  invite_count integer default 0,
  invite_score numeric default 0,
  feed_preferences jsonb default '{}'::jsonb,
  hidden_post_ids jsonb default '[]'::jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists draws (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  title text not null,
  status text default 'active',
  starts_at timestamptz default now(),
  ends_at timestamptz,
  closed_at timestamptz,
  winner_post_id uuid,
  created_at timestamptz default now()
);

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid references draws(id) on delete cascade,
  profile_id uuid references profiles(id) on delete set null,
  title text,
  body text not null,
  votes numeric default 0,
  ai_score numeric default 0,
  quality_score numeric default 0,
  visibility_score numeric default 1,
  boost_visibility numeric default 0,
  boost_count integer default 0,
  boost_last_at timestamptz,
  audience_fit_score numeric default 0,
  hook_score numeric default 0,
  feed_score numeric default 0,
  feed_rank integer,
  feed_explanation text,
  personalization_score numeric default 0,
  audience_score numeric default 0,
  moderation_status text default 'pending',
  moderation_reason text,
  shadow_status text default 'visible',
  shadow_reason text,
  reason_summary text,
  win_reason text,
  hidden_rank numeric default 0,
  final_score numeric default 0,
  is_bot_generated boolean default false,
  status text default 'active',
  created_at timestamptz default now()
);

create table if not exists votes (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid references draws(id) on delete cascade,
  post_id uuid references posts(id) on delete cascade,
  profile_id uuid references profiles(id) on delete cascade,
  value numeric default 1,
  source text default 'user',
  created_at timestamptz default now()
);

create table if not exists draw_results (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid references draws(id) on delete cascade,
  draw_type text,
  post_id uuid references posts(id) on delete set null,
  profile_name text,
  final_score numeric,
  votes numeric,
  ai_score numeric,
  summary text,
  reason_summary text,
  created_at timestamptz default now()
);

create table if not exists mentor_feedback (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id) on delete cascade,
  post_id uuid references posts(id) on delete cascade,
  feedback text,
  strengths jsonb,
  improvements jsonb,
  created_at timestamptz default now()
);

create table if not exists reputation_events (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id) on delete cascade,
  event_type text not null,
  delta numeric not null default 0,
  previous_score numeric,
  new_score numeric,
  meta jsonb,
  created_at timestamptz default now()
);

create table if not exists round_insights (
  id uuid primary key default gen_random_uuid(),
  draw_id uuid references draws(id) on delete cascade,
  insight_type text not null,
  content text,
  data jsonb,
  created_at timestamptz default now()
);

create table if not exists moderation_events (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts(id) on delete cascade,
  moderation_status text,
  reason text,
  created_at timestamptz default now()
);

create table if not exists feed_impressions (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id) on delete cascade,
  post_id uuid references posts(id) on delete cascade,
  draw_id uuid references draws(id) on delete cascade,
  action text,
  dwell_ms integer,
  created_at timestamptz default now()
);

create table if not exists post_boosts (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts(id) on delete cascade,
  profile_id uuid references profiles(id) on delete cascade,
  draw_id uuid references draws(id) on delete cascade,
  visibility_gain numeric not null default 0,
  created_at timestamptz default now()
);

create table if not exists invites (
  id uuid primary key default gen_random_uuid(),
  inviter_id uuid references profiles(id) on delete cascade,
  invited_id uuid references profiles(id) on delete cascade,
  status text default 'pending',
  created_at timestamptz default now(),
  activated_at timestamptz
);

create table if not exists app_config (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz default now()
);

create table if not exists analytics_events (
  id uuid primary key default gen_random_uuid(),
  event text,
  data jsonb,
  created_at timestamptz default now()
);

create index if not exists votes_unique_per_profile_post_draw on votes(draw_id, post_id, profile_id);
create index if not exists posts_draw_status_idx on posts(draw_id, status);
create index if not exists posts_feed_score_idx on posts(draw_id, status, feed_score desc);
create index if not exists posts_shadow_status_idx on posts(draw_id, status, shadow_status);
create index if not exists draws_type_status_idx on draws(type, status);
create index if not exists reputation_events_profile_idx on reputation_events(profile_id, created_at desc);
create index if not exists feed_impressions_profile_idx on feed_impressions(profile_id, created_at desc);
create index if not exists post_boosts_post_idx on post_boosts(post_id);
create index if not exists invites_inviter_idx on invites(inviter_id);

create or replace function increment_invite_stats(user_id uuid)
returns void as $$
begin
  update profiles
  set invite_count = invite_count + 1,
      invite_score = invite_score + 0.05,
      updated_at = now()
  where id = user_id;
end;
$$ language plpgsql;
