-- 02_policies.sql
alter table profiles enable row level security;
alter table posts enable row level security;
alter table votes enable row level security;
alter table draws enable row level security;
alter table draw_results enable row level security;
alter table mentor_feedback enable row level security;
alter table reputation_events enable row level security;
alter table round_insights enable row level security;
alter table moderation_events enable row level security;
alter table feed_impressions enable row level security;
alter table post_boosts enable row level security;
alter table invites enable row level security;
alter table app_config enable row level security;
alter table analytics_events enable row level security;

drop policy if exists "read own profile" on profiles;
create policy "read own profile" on profiles for select using (auth.uid() = auth_user_id or is_bot = true);

drop policy if exists "insert own profile" on profiles;
create policy "insert own profile" on profiles for insert with check (auth.uid() = auth_user_id);

drop policy if exists "update own profile" on profiles;
create policy "update own profile" on profiles for update using (auth.uid() = auth_user_id);

drop policy if exists "read posts" on posts;
create policy "read posts" on posts for select using (true);

drop policy if exists "read draws" on draws;
create policy "read draws" on draws for select using (true);

drop policy if exists "read results" on draw_results;
create policy "read results" on draw_results for select using (true);

drop policy if exists "read mentor own" on mentor_feedback;
create policy "read mentor own" on mentor_feedback for select using (
  exists (select 1 from profiles p where p.id = mentor_feedback.profile_id and p.auth_user_id = auth.uid())
);

drop policy if exists "read reputation own" on reputation_events;
create policy "read reputation own" on reputation_events for select using (
  exists (select 1 from profiles p where p.id = reputation_events.profile_id and p.auth_user_id = auth.uid())
);

drop policy if exists "read round insights" on round_insights;
create policy "read round insights" on round_insights for select using (true);

drop policy if exists "read analytics none" on analytics_events;
create policy "read analytics none" on analytics_events for select using (false);
